package CDP_1;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.awt.image.DataBufferByte;

public class MusicMatrix {
	Matrix musicMatrix;
	int m, n;
	int scansize_w = 15, scansize_h;
	int bottom_h, top_h;
	int notes;
	int instrumentNumber;
	
	BufferedImage image;
	
	MusicMatrix(int notes, int instrumentNumber, BufferedImage image){
		//�̹��� ��ջ� ���ϱ�
		MeanColor mc= new MeanColor(image);
		int[] melody = mc.melody;
		int[][] hmn = mc.hmn;
		
		
		this.notes = notes;
		this.instrumentNumber = instrumentNumber;
		this.image = image;
		
		
		if (notes == 14) {
			////�̹��� �ܰ��� �̹����� �ٲٱ�
			System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
			
			//BufferedImage -> Mat
			Mat color = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
			byte[] data = ((DataBufferByte)image.getRaster().getDataBuffer()).getData();
			color.put(0, 0, data);
//			Mat color = Imgcodecs.imread("D:\\gugu_color.jpg");

			Mat gray = new Mat();
			Mat draw = new Mat();
			Mat wide = new Mat();

			//use canny-edge
			Imgproc.cvtColor(color, gray, Imgproc.COLOR_BGR2GRAY);
			Imgproc.Canny(gray, wide, 50, 150, 3, false);
			wide.convertTo(draw, CvType.CV_8U);

			//Mat-> BufferedImage
			MatOfByte matOfByte = new MatOfByte();
			Imgcodecs.imencode(".jpg", color, matOfByte);
			byte[] byteArray = matOfByte.toArray();
			BufferedImage outlineImage = null;

			InputStream in = new ByteArrayInputStream(byteArray);
			try {
				outlineImage = ImageIO.read(in);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			this.image = outlineImage;
			createMalodyMatrix(melody);
		}
		if(notes == 9) {
			createHmnMatrix(hmn);
		}
	}
	
	void createMalodyMatrix(int[] melody) {
		int width = image.getWidth(), height = image.getHeight();
		bottom_h = height;
		top_h = 0;
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				Color color = new Color(image.getRGB(i, j));
				int red = color.getRed();

				if ((red < 100)) {
					if (bottom_h > j)
						bottom_h = j;
					if (top_h < j)
						top_h = j;
				}
			}
		}
		height = top_h - bottom_h;
		scansize_h = (int) Math.ceil(height / (double) notes);

		m = notes;
		// m = (int) Math.ceil(height / scansize_h);
		n = (int) Math.ceil(width / scansize_w);

		musicMatrix = new Matrix(m, n);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {

				int scansize_w2 = scansize_w, scansize_h2 = scansize_h;
				if ((j + 1) * scansize_w > width && (i + 1) * scansize_h > height) {
					scansize_w2 = width - j * scansize_w;
					scansize_h2 = height - i * scansize_h;
				} else if ((j + 1) * scansize_w > width) {
					scansize_w2 = width - j * scansize_w;
				} else if ((i + 1) * scansize_h > height) {
					scansize_h2 = height - i * scansize_h;
				}
				int[] rgbArray = new int[scansize_w2 * scansize_h2];
				image.getRGB(j * scansize_w, i * scansize_h + bottom_h, scansize_w2, scansize_h2, rgbArray, 0, 1);
				
				int red=0;
				for (int num : rgbArray) {
					if (num == 0)
						break; // null�ϱ�??? 0��??
					Color color = new Color(num);
					red = color.getRed();
					if(red<25) {
						break;
					}
					else {
						red=0;
					}
				}
				if (red != 0) {
					musicMatrix.set(i, j, 1);
				} else {
					musicMatrix.set(i, j, 0);
				}
			}
		} // end for
		
		setMelodyCode(musicMatrix, melody);
		
	}

	void createHmnMatrix(int[][] hmn) {
		int width = image.getWidth(), height = image.getHeight();
		scansize_h = (int) Math.ceil(height / (double) notes);

		m = notes;
		// m = (int) Math.ceil(height / scansize_h);
		n = (int) Math.ceil(width / scansize_w);

		musicMatrix = new Matrix(m, n);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {

				int scansize_w2 = scansize_w, scansize_h2 = scansize_h;
				if ((j + 1) * scansize_w > width && (i + 1) * scansize_h > height) {
					scansize_w2 = width - j * scansize_w;
					scansize_h2 = height - i * scansize_h;
				} else if ((j + 1) * scansize_w > width) {
					scansize_w2 = width - j * scansize_w;
				} else if ((i + 1) * scansize_h > height) {
					scansize_h2 = height - i * scansize_h;
				}
				int[] rgbArray = new int[scansize_w2 * scansize_h2];
				image.getRGB(j * scansize_w, i * scansize_h, scansize_w2, scansize_h2, rgbArray, 0, 1);

				int colorNumber = getColorNumber(rgbArray);
				if (colorNumber == instrumentNumber) {
					musicMatrix.set(i, j, colorNumber);
				} else {
					musicMatrix.set(i, j, 0);
				}
			}
		} // end for
		
		setCode(musicMatrix, hmn);
		
		
	}

	void setMelodyCode(Matrix musicMatrix, int[] melody) {
		m = musicMatrix.nrows();
		n = musicMatrix.ncols();

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if (musicMatrix.get(i, j) > 0) {
					int data = melody[i];
					musicMatrix.set(i, j, data);
				}
			}
		}
	}

	void setCode(Matrix musicMatrix, int[][] hmn) {
		m = musicMatrix.nrows();
		n = musicMatrix.ncols();
		
		for (int i = 0; i < m; i++) {
			int j = 0;
			for (; j < n / 4; j++) {
				if (musicMatrix.get(i, j) > 0) {
					int data = hmn[0][i];
					musicMatrix.set(i, j, data);
				}
			}
			for (; j < n / 4 * 2; j++) {
				if (musicMatrix.get(i, j) > 0) {
					int data = hmn[1][i];
					musicMatrix.set(i, j, data);
				}
			}
			for (; j < n / 4 * 3; j++) {
				if (musicMatrix.get(i, j) > 0) {
					int data = hmn[2][i];
					musicMatrix.set(i, j, data);
				}
			}
			for (; j < n; j++) {
				if (musicMatrix.get(i, j) > 0) {
					int data = hmn[3][i];
					musicMatrix.set(i, j, data);
				}
			}
		}

	}

	public int getColorNumber(int[] rgbArray) {
		int[][] color_chart = { { 255, 255, 255 }, { 237, 28, 36 }, { 255, 127, 39 }, { 255, 242, 0 }, { 34, 177, 76 },
				{ 0, 162, 232 }, { 63, 72, 204 }, { 163, 73, 164 }, { 127, 127, 127 }, { 0, 0, 0 } };
		int colorNumber = 0;
		int r = 0, g = 0, b = 0, i = 0;
		for (int num : rgbArray) {
			if (num == 0)
				break; // null�ϱ�??? 0��??
			Color color = new Color(num);
			r += color.getRed();
			g += color.getGreen();
			b += color.getBlue();
			i++;
		}
		r = r / i;
		g = g / i;
		b = b / i;
		double min = 0, temp = 442;
		for (i = 0; i < 10; i++) {
			min = Math.sqrt((r - color_chart[i][0]) ^ 2 + (g - color_chart[i][1]) ^ 2 + (b - color_chart[i][2]) ^ 2);
			if (min < temp) {
				temp = min;
				colorNumber = i;
			}
		}
		return colorNumber;

	}
	

}