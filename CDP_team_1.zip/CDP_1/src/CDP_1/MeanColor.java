package CDP_1;


import java.awt.Color;
import java.awt.image.BufferedImage;

public class MeanColor {

	int[] melody_C = { 83, 81, 79, 77, 76, 74, 72, 71, 69, 67, 65, 64, 62, 60 };
	int[] melody_CS = { 72, 70, 68, 66, 65, 63, 61, 60, 58, 56, 54, 53, 51, 49 };
	int[] melody_D = { 73, 71, 69, 67, 66, 64, 62, 61, 59, 57, 55, 54, 52, 50 };
	int[] melody_DS = { 74, 72, 70, 68, 67, 65, 63, 62, 60, 58, 56, 55, 53, 51 };
	int[] melody_E = { 75, 73, 71, 69, 68, 66, 64, 63, 61, 59, 57, 56, 54, 52 };
	int[] melody_F = { 76, 74, 72, 70, 69, 67, 65, 64, 62, 60, 58, 57, 55, 53 };
	int[] melody_FS = { 77, 75, 73, 71, 70, 68, 66, 65, 63, 61, 59, 58, 56, 54 };
	int[] melody_G = { 78, 76, 74, 72, 71, 69, 67, 66, 64, 62, 60, 59, 57, 55 };
	int[] melody_GS = { 79, 77, 75, 73, 72, 70, 68, 67, 65, 63, 61, 60, 58, 56 };
	int[] melody_A = { 80, 78, 76, 74, 73, 71, 69, 68, 66, 64, 62, 61, 59, 57 };
	int[] melody_AS = { 81, 79, 77, 75, 74, 72, 70, 69, 67, 65, 63, 62, 60, 58 };
	int[] melody_B = { 82, 80, 78, 76, 75, 73, 71, 70, 68, 66, 64, 63, 61, 59 };

	int[] hmn_C = { 79, 76, 72, 67, 64, 60, 55, 52, 48 };
	int[] hmn_Am = { 76, 72, 69, 64, 60, 57, 52, 48, 45 };
	int[] hmn_Dm = { 69, 65, 62, 57, 53, 50, 45, 41, 38 };
	int[] hmn_G = { 74, 71, 67, 62, 59, 55, 50, 47, 43 };
	int[] hmn_CS = { 68, 65, 61, 56, 53, 49, 44, 41, 37 };
	int[] hmn_ASm = { 77, 73, 70, 65, 61, 58, 53, 49, 46 };
	int[] hmn_DSm = { 70, 66, 63, 58, 54, 51, 46, 42, 39 };
	int[] hmn_GS = { 75, 72, 68, 63, 60, 56, 51, 48, 44 };
	int[] hmn_D = { 69, 66, 62, 57, 54, 50, 45, 42, 38 };
	int[] hmn_Bm = { 78, 74, 71, 66, 62, 59, 54, 50, 47 };
	int[] hmn_Em = { 71, 67, 64, 59, 55, 52, 47, 43, 40 };
	int[] hmn_A = { 76, 73, 69, 64, 61, 57, 52, 49, 45 };
	int[] hmn_DS = { 70, 67, 63, 58, 55, 51, 46, 43, 39 };
	int[] hmn_Cm = { 79, 75, 72, 67, 63, 60, 55, 51, 48 };
	int[] hmn_Fm = { 72, 68, 65, 60, 56, 53, 48, 44, 41 };
	int[] hmn_AS = { 77, 74, 70, 65, 62, 58, 53, 50, 46 };
	int[] hmn_E = { 71, 68, 64, 59, 56, 52, 47, 44, 40 };
	int[] hmn_CSm = { 80, 76, 73, 68, 64, 61, 56, 52, 49 };
	int[] hmn_FSm = { 73, 70, 66, 61, 58, 54, 49, 46, 42 };
	int[] hmn_B = { 78, 75, 71, 66, 63, 59, 54, 51, 48 };
	int[] hmn_F = { 72, 69, 65, 60, 57, 53, 48, 45, 41 };
	int[] hmn_Gm = { 74, 70, 67, 62, 58, 55, 50, 46, 43 };
	int[] hmn_FS = { 73, 70, 66, 61, 58, 54, 49, 46, 42 };
	int[] hmn_GSm = { 75, 71, 68, 63, 59, 56, 51, 47, 44 };

	int[][] color_chart = { { 255, 0, 0 }, { 199, 21, 133 }, { 238, 130, 238 }, { 138, 43, 226 }, { 0, 0, 255 },
			{ 0, 221, 221 }, { 0, 255, 0 }, { 154, 205, 50 }, { 255, 255, 0 }, { 255, 174, 66 }, { 255, 165, 0 },
			{ 255, 83, 73 } };

	int[] melody=new int[14];
	int[][] hmn=new int[4][9];

	MeanColor(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();

		int r = 0, g = 0, b = 0;
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				Color c = new Color(image.getRGB(i, j));
				r += c.getRed();
				g += c.getGreen();
				b += c.getBlue();
			}
		}
		int p = w * h;
		r = r / p;
		g = g / p;
		b = b / p;

		
		
		int colorNumber = 0;
		double min = 0, temp = 442;
		for (int i = 0; i < 12; i++) {
			min = Math.sqrt( Math.pow(r - color_chart[i][0], 2) + 
					Math.pow(r - color_chart[i][1], 2)+
					Math.pow(r - color_chart[i][2], 2) );

			if (min < temp) {
				temp = min;
				colorNumber = i;
				
			}
		}
		

		switch (colorNumber) {
		case 0:
			System.arraycopy(melody_C, 0, melody, 0, 14);

			System.arraycopy(hmn_C, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Am, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Dm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_G, 0, hmn[3], 0, 9);
			break;
		case 1:
			System.arraycopy(melody_CS, 0, melody, 0, 14);

			System.arraycopy(hmn_CS, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_ASm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_DSm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_GS, 0, hmn[3], 0, 9);
			break;
		case 2:
			System.arraycopy(melody_D, 0, melody, 0, 14);

			System.arraycopy(hmn_D, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Bm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Em, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_A, 0, hmn[3], 0, 9);
			break;
		case 3:
			System.arraycopy(melody_DS, 0, melody, 0, 14);

			System.arraycopy(hmn_DS, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Cm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Fm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_AS, 0, hmn[3], 0, 9);
			break;
		case 4:
			System.arraycopy(melody_E, 0, melody, 0, 14);

			System.arraycopy(hmn_E, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_CSm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_FSm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_B, 0, hmn[3], 0, 9);
			break;
		case 5:
			System.arraycopy(melody_F, 0, melody, 0, 14);

			System.arraycopy(hmn_F, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Dm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Gm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_C, 0, hmn[3], 0, 9);
			break;
		case 6:
			System.arraycopy(melody_FS, 0, melody, 0, 14);

			System.arraycopy(hmn_FS, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_DSm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_GSm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_CS, 0, hmn[3], 0, 9);
			break;
		case 7:
			System.arraycopy(melody_G, 0, melody, 0, 14);
			
			System.arraycopy(hmn_G, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Em, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Am, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_D, 0, hmn[3], 0, 9);
			break;
		case 8:
			System.arraycopy(melody_GS, 0, melody, 0, 14);

			System.arraycopy(hmn_GS, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Fm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_ASm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_DS, 0, hmn[3], 0, 9);
			break;
		case 9:
			System.arraycopy(melody_A, 0, melody, 0, 14);

			System.arraycopy(hmn_A, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_FSm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Dm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_Em, 0, hmn[3], 0, 9);
			break;
		case 10:
			System.arraycopy(melody_AS, 0, melody, 0, 14);

			System.arraycopy(hmn_AS, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_Gm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_Cm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_F, 0, hmn[3], 0, 9);
			break;
		case 11:
			System.arraycopy(melody_B, 0, melody, 0, 14);

			System.arraycopy(hmn_B, 0, hmn[0], 0, 9);
			System.arraycopy(hmn_GSm, 0, hmn[1], 0, 9);
			System.arraycopy(hmn_CSm, 0, hmn[2], 0, 9);
			System.arraycopy(hmn_FS, 0, hmn[3], 0, 9);
			break;
		}

	
	}
}
