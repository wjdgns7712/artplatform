package CDP_1;


import java.awt.image.BufferedImage;
import java.io.*;
import javax.sound.midi.*; // package for all midi classes



public class CreateMusic {
	final int PROGRAM = 192;
	final int NOTEON = 144;
	final int NOTEOFF = 128;
	Sequencer sequencer;
	Sequence sequence;
	Synthesizer synthesizer;
	Instrument instruments[];
	ChannelData channels[];
	ChannelData cc;
	Track track;
	boolean record = true;
	BufferedImage image;

	int[] instrumentCheck = { 0, 33, 40, 48, 16, 24, 89, 72, 4 };
//35, 40, 48, 50, 35, 43, 35, 0
	void play() {
		// ����϶�
		try {
			sequencer.open();
			sequencer.setSequence(sequence);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		sequencer.start();
	}

	void stop() {
		// // ��� ���Ҷ�
		sequencer.stop();
	}

	void record(String filePath) {
		File f = new File(filePath);
		try {
			MidiSystem.write(sequence, 1, f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	CreateMusic(BufferedImage image) throws InvalidMidiDataException {
		System.out.println("CreateMusic ");
		open();

		track = sequence.createTrack();
		createShortEvent(PROGRAM, 0);

		MusicMatrix mainM = new MusicMatrix(14, 1, image);
		Matrix melodyMatrix = mainM.musicMatrix;
		setMelodyNote(melodyMatrix);

		for (int i = 1; i < 9; i++) {
			cc = channels[i];
			// instrument change
			int instrument = instrumentCheck[i];
			programChange(instrument); // instrument number
			track = sequence.createTrack();
			createShortEvent(PROGRAM, instrument);

			// i=1�϶� �Ǳ� -���ǿ� ������ 35��, matrix�� ���鶩 1�� �־����
			// �ֳĸ� �Ǳ�� �׸� �� ���ڶ� ����Ǿ��־
			// 1�� �Ǳ�=1�� ������ ��Ÿ��
			MusicMatrix music = new MusicMatrix(9, i, image);
			Matrix hmnMatrix = music.musicMatrix;
			setHmnNote(instrument, hmnMatrix);
		}

		// close();

	}

	class TrackData extends Object {
		Integer chanNum;
		String name;
		Track track;

		public TrackData(int chanNum, String name, Track track) {
			this.chanNum = new Integer(chanNum);
			this.name = name;
			this.track = track;
		}
	} // End class TrackData

	static class ChannelData {

		MidiChannel channel;
		boolean solo, mono, mute, sustain;
		int velocity, pressure, bend, reverb;
		int row, col, num;

		public ChannelData(MidiChannel channel, int num) {
			this.channel = channel;
			this.num = num;
			velocity = 60;
			pressure = bend = reverb = 0;
		}
	} // End class ChannelData

	// 33, 40, 48, 16, 24, 89, 72, 4

	void noteOnOff(int note, int time, int time_interval) {
		cc.channel.noteOn(note, cc.velocity);
		createNoteShortEvent(NOTEON, note, time);

		cc.channel.noteOff(note, cc.velocity);
		createNoteShortEvent(NOTEOFF, note, time + time_interval);
	}

	void setMelodyNote(Matrix melodyMatrix) {
		// Matrix melodyMatrix = music.musicMatrix;
		int n = melodyMatrix.ncols();
		int m = melodyMatrix.nrows();
		double[] col_data_num = new double[n];
		boolean[] up_down = new boolean[n];

		for (int i = 0; i < n; i++) {
			int num = melodyMatrix.n_col_data(i);
			double median = melodyMatrix.col_median(i);// get median
			if (num == 1) {
				for (int j = 0; j < m; j++) { // delete max diff data
					melodyMatrix.set(j, i, 0);
				}
				num = 0;
			}
			while (num == 1 || (num & (num - 1)) != 0 || num > 4) { // if not 2^n
				col_data_num = melodyMatrix.col_data(i);
				double max = 0;
				double max_col_data = 0;
				for (int j = 0; j < col_data_num.length; j++) { // get max diff
					if (Math.abs(col_data_num[j] - median) > max) {
						max = Math.abs(col_data_num[j] - median);
						max_col_data = col_data_num[j];
					}
				}
				for (int j = 0; j < m; j++) { // delete max diff data
					if (max_col_data == melodyMatrix.get(j, i)) {
						melodyMatrix.set(j, i, 0);
						break;
					}
				}
				num = melodyMatrix.n_col_data(i);

			} // end while
		}

		double prev = 0;
		for (int i = 0; i < n - 1; i++) {
			double cur = melodyMatrix.col_mean(i);
			double next = melodyMatrix.col_mean(i + 1);
			if (cur > next) {// ���� ��>���� �� -> ���翭 down
				up_down[i] = false;
			} else if (cur < next) {// ���� ��<���� �� -> ���翭 up
				up_down[i] = true;
			} else {// ���� ��= ������ -> ���翭�� ���� ���� �ݴ�
				if (prev == 0) {
					up_down[i] = true;
				} else {
					up_down[i] = !up_down[i - 1];
				}
			}
			prev = cur;
		}
		up_down[n - 1] = false;

		for (int i = 0; i < n; i++) {
			int n_col = melodyMatrix.n_col_data(i);
			if (n_col != 0) {
				int time_interval = 12 / n_col;
				int k = 0;
				if (up_down[i]) {
					for (int j = m - 1; j >= 0; j--) {
						int note = (int) melodyMatrix.get(j, i);
						if (note != 0) {
							noteOnOff(note, i * 12 + time_interval * k, time_interval);
							k++;
						}
					}
				} else {
					for (int j = 0; j < m; j++) {
						int note = (int) melodyMatrix.get(j, i);
						if (note != 0) {
							noteOnOff(note, i * 12 + time_interval * k, time_interval);
							k++;
						}
					}
				}
			}
		}
	}

	void setHmnNote(int instrument, Matrix hmnMatrix) {

		int n = hmnMatrix.ncols();
		int m = hmnMatrix.nrows();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				int note = (int) hmnMatrix.get(j, i);
				if (note != 0) {
					noteOnOff(note, i * 12, 12);
				}
			}
		}
	}

	void open() {
		try {
			if (synthesizer == null) {
				if ((synthesizer = MidiSystem.getSynthesizer()) == null) {
					System.out.println("getSynthesizer() failed!");
					return;
				}
			}
			synthesizer.open();
			sequencer = MidiSystem.getSequencer();
			sequence = new Sequence(Sequence.PPQ, 10);
		} catch (Exception ex) {
			ex.printStackTrace();
			return;
		}

		Soundbank sb = synthesizer.getDefaultSoundbank();

		if (sb != null) {
			instruments = synthesizer.getDefaultSoundbank().getInstruments();
			synthesizer.loadInstrument(instruments[40]);
		}
		MidiChannel midiChannels[] = synthesizer.getChannels();
		channels = new ChannelData[midiChannels.length];
		for (int i = 0; i < channels.length; i++) {
			channels[i] = new ChannelData(midiChannels[i], i);
		}
		cc = channels[0];
	}

	void close() {
		if (synthesizer != null) {
			synthesizer.close();
		}
		if (sequencer != null) {
			sequencer.close();
		}
		sequencer = null;
		synthesizer = null;
		instruments = null;
		channels = null;
	}

	void createShortEvent(int type, int num) {
		ShortMessage message = new ShortMessage();
		try {

			message.setMessage(type + cc.num, num, cc.velocity);
			MidiEvent event = new MidiEvent(message, 0);
			track.add(event);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void createNoteShortEvent(int type, int note, int time) {
		ShortMessage message = new ShortMessage();
		try {
			message.setMessage(type + cc.num, note, cc.velocity);
			MidiEvent event = new MidiEvent(message, time);
			track.add(event);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void programChange(int program) {
		if (instruments != null) {
			synthesizer.loadInstrument(instruments[program]);
		}
		cc.channel.programChange(program);

		if (record) {
			createShortEvent(PROGRAM, program);
		}
	}
}