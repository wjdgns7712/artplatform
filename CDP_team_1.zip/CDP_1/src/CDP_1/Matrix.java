package CDP_1;


public class Matrix {
	private int m, n;
	private double[][] A;

	public Matrix(int m, int n) {
		this.m = m;
		this.n = n;

		A = new double[m][n];
	}

	public int nrows() {
		return m;
	}

	public int ncols() {
		return n;
	}

	public int length() {
		return n * m;
	}

	public double get(int i, int j) {
		return A[i][j];
	}

	public void set(int i, int j, double data) {
		A[i][j] = data;
	}
	

	public int n_row_data(int row) {
		int num = 0;
		for (int j = 0; j < n; j++) {
			if (A[row][j] > 0) {
				num++;
			}
		}
		return num;
	}

	public int n_col_data(int col) {
		int num = 0;
		for (int i = 0; i < m; i++) {
			// System.out.println("A["+i+"][col]: " + A[i][col]);
			if (A[i][col] > 0) {
				num++;
			}
		}
		return num;
	}

	public double[] col_data(int col) {
		int n_data = n_col_data(col);
		double[] col_data = new double[n_data];
		int k = 0;

		for (int i = 0; i < m; i++) {
			double data = A[i][col];
			if (data > 0) {
				// System.out.println("col_data["+k+"]: " + data);
				col_data[k] = data;
				k++;
			}
		}
		return col_data;
	}

	public double col_median(int col) {
		double median=0;
		double[] col_data = col_data(col);
		if(col_data.length == 0) {
			median=0;
			return median;
		}
		if(col_data.length % 2 ==0) {
			median = col_data[col_data.length/2]; //0 1 2 3 -> 4/2=2
		}
		else {
			median = col_data[col_data.length/2]; // 0 1 2 -> 3/2=1
		}
		return median;
	}
	public double col_mean(int col) {
		double mean=0;
		double[] col_data = col_data(col);
		for(int i=0; i<col_data.length; i++) {
			mean+=col_data[i];
		}
		mean = mean/col_data.length;
		return mean;
	}
	public double[] col_data_reverse(int col) {
		double[] col_data = col_data(col);
		double[] col_data_r = new double[col_data.length];
		for (int i = 0; i < col_data.length; i++) {
			col_data_r[i] = col_data[col_data.length - i - 1];
		}
		return col_data_r;
	}

	public void print_matrix() {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				int data = (int) A[i][j];
				System.out.printf("%3d", data);
			}
			System.out.println(" ");
		}
	}

	public double sum() {
		double sum = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				sum += A[i][j];
			}
		}
		return sum;
	}
	public double n_data() {
		double sum = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if(A[i][j]>0) {
					sum++;
				}
			}
		}
		return sum;
	}

	public double sum(int w, int h, int scansize_w, int scansize_h) {
		double sum = 0;
		int max_w = w + scansize_w - 1, max_h = h + scansize_h - 1;
		if (m < max_w) {
			max_w = m;
		}
		if (n < max_h) {
			max_h = n;
		}

		for (int i = w; i < max_w; i++) {
			for (int j = h; j < max_h; j++) {
				sum += A[i][j];
			}
		}
		return sum;
	}

	public double average(Matrix matrix) {
		double aver = 0;
		aver = matrix.sum();
		aver = aver / (matrix.nrows() * matrix.ncols());
		return aver;
	}

	public double average(int w, int h, int size_w, int size_h) {
		double aver = 0;
		aver = sum(w, h, size_w, size_h);
		aver = aver / (size_w * size_h);
		return aver;
	}

	public Matrix transpose() {
		Matrix X = new Matrix(n, m);
		double[][] C = X.getArray();
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				C[j][i] = A[i][j];
			}
		}
		return X;
	}

	public double[][] getArray() {
		return A;
	}

	public Matrix detach_Matrix(int num, Matrix matrix) {
		int m = matrix.nrows();
		int n = matrix.ncols();
		Matrix detachMatrix = new Matrix(m, n);

		for (int x = 0; x < m; x++) {
			for (int y = 0; y < n; y++) {
				int data = (int) matrix.get(x, y);
				if (num == data) {
					detachMatrix.set(x, y, data);
				} else {
					detachMatrix.set(x, y, 0);
				}

			}
		}
		// detachMatrix.print_matrix();
		System.out.println("");
		return detachMatrix;
	}

	

}
