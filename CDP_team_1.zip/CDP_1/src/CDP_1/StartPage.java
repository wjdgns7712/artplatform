package CDP_1;


import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.midi.InvalidMidiDataException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

@SuppressWarnings("serial")
public class StartPage extends JFrame {
	private Image screenImage;
	private Graphics screenGraphic;
	CreateMusic createMusic;
	
	
	private ImageIcon exitButtonEnteredImage = new ImageIcon(getClass().getClassLoader().getResource("exitButtonEntered.png"));
	private ImageIcon exitButtonBasicImage = new ImageIcon(getClass().getClassLoader().getResource("exitButtonBasic.png"));
	private ImageIcon startButtonEnteredImage = new ImageIcon(
			getClass().getClassLoader().getResource("startButtonEntered.png"));
	private ImageIcon startButtonBasicImage = new ImageIcon(getClass().getClassLoader().getResource("startButtonBasic.png"));
	private ImageIcon quitButtonEnteredImage = new ImageIcon(getClass().getClassLoader().getResource("quitButtonEntered.png"));
	private ImageIcon quitButtonBasicImage = new ImageIcon(getClass().getClassLoader().getResource("quitButtonBasic.png"));

	
	private Image background = new ImageIcon(getClass().getClassLoader().getResource("introBackground.jpg")).getImage();;
	//private JLabel menuBar = new JLabel(new ImageIcon(getClass().getClassLoader().getResource("menuBar.png")));

	private JButton exitButton = new JButton(exitButtonBasicImage);
	private JButton startButton = new JButton(startButtonBasicImage);
	private JButton quitButton = new JButton(quitButtonBasicImage);

	
	
	
	private ImageIcon pictureButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("pictureButtonBasic.png"));
	private ImageIcon drawingButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("drawingButtonBasic.png"));
	private ImageIcon videoButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("videoButtonBasic.png"));
	
	private JButton pictureButton = new JButton(pictureButtonBasicImage);
	private JButton drawingButton = new JButton(drawingButtonBasicImage);
	private JButton videoButton = new JButton(videoButtonBasicImage);


	
	
	private ImageIcon fileInputButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("fileInputButtonBasic.png"));
	private JButton fileInputButton = new JButton(fileInputButtonBasicImage);
	
	
	
	
	private ImageIcon playButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("playButton.png"));
	private ImageIcon stopButtonBasicImage = new ImageIcon(
			getClass().getClassLoader().getResource("stopButton.png"));
	
	private JButton playButton = new JButton(playButtonBasicImage);
	private JButton stopButton = new JButton(stopButtonBasicImage);
	
	
	
	private ImageIcon pointer_service1Image = new ImageIcon(
			getClass().getClassLoader().getResource("pointer_service1.png"));
	private JButton pointer_service1Button = new JButton(pointer_service1Image);
	
	

	private ImageIcon saveImage = new ImageIcon(
			getClass().getClassLoader().getResource("save.png"));
	private ImageIcon againImage = new ImageIcon(
			getClass().getClassLoader().getResource("again.png"));
	private ImageIcon mainImage = new ImageIcon(
			getClass().getClassLoader().getResource("main.png"));
	
	private JButton saveButton = new JButton(saveImage);
	private JButton againButton = new JButton(againImage);
	private JButton mainButton = new JButton(mainImage);
	
	
	
	@SuppressWarnings("unused")
	private Image fileImage;
	
	

	public StartPage() {
		setUndecorated(true);
		setTitle("ART PLATFORM");
		setSize(ArtPlatform.SCREEN_WIDTH, ArtPlatform.SCREEN_HEIGHT);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setBackground(new Color(0, 0, 0, 0));
		setLayout(null);

		exitButton.setBounds(1245, 0, 30, 30);
		exitButton.setBorderPainted(false);
		exitButton.setContentAreaFilled(false);
		exitButton.setFocusPainted(false);
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				exitButton.setIcon(exitButtonEnteredImage);
				exitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				exitButton.setIcon(exitButtonBasicImage);
				exitButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				System.exit(0);
			}
		});
		add(exitButton);

		startButton.setBounds(200, 550, 400, 100);
		startButton.setBorderPainted(false);
		startButton.setContentAreaFilled(false);
		startButton.setFocusPainted(false);
		startButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				startButton.setIcon(startButtonEnteredImage);
				startButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				startButton.setIcon(startButtonBasicImage);
				startButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				startButton.setVisible(false);
				quitButton.setVisible(false);
				
				pictureButton.setVisible(true);
				drawingButton.setVisible(true);
				videoButton.setVisible(true);
				background = new ImageIcon(getClass().getClassLoader().getResource("mainBackground.PNG"))
						.getImage();
				//System.out.println("startPage");
				
			}
		});
		add(startButton);

		quitButton.setBounds(650, 550, 400, 100);
		quitButton.setBorderPainted(false);
		quitButton.setContentAreaFilled(false);
		quitButton.setFocusPainted(false);
		quitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				quitButton.setIcon(quitButtonEnteredImage);
				quitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				quitButton.setIcon(quitButtonBasicImage);
				quitButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mousePressed(MouseEvent e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				System.exit(0);
			}
		});
		add(quitButton);

		
		pictureButton.setBounds(33, 285, 390, 369);
		pictureButton.setBorderPainted(false);
		pictureButton.setContentAreaFilled(false);
		pictureButton.setFocusPainted(false);
		pictureButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//.out.println("pictureButton");
				
				pictureButton.setVisible(false);
				drawingButton.setVisible(false);
				videoButton.setVisible(false);
				
				
				background = new ImageIcon(getClass().getClassLoader().getResource("service1Background1.PNG"))
						.getImage(); 
				fileInputButton.setVisible(true);


			}

			@SuppressWarnings("unused")
			private String getResource(String string) {
				// TODO Auto-generated method stub
				return null;
			}
		});
		add(pictureButton);

		drawingButton.setBounds(445, 283, 390, 369);
		drawingButton.setBorderPainted(false);
		drawingButton.setContentAreaFilled(false);
		drawingButton.setFocusPainted(false);
		drawingButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
				pictureButton.setVisible(false);
				drawingButton.setVisible(false);
				videoButton.setVisible(false);
				
				
				background = new ImageIcon(getClass().getClassLoader().getResource("seeYouSoon.PNG")).getImage(); // TO
																														// DO
				
				// MainPage mainPage = new MainPage();

			}
		});
		add(drawingButton);

		videoButton.setBounds(852, 285, 390, 369);
		videoButton.setBorderPainted(false);
		videoButton.setContentAreaFilled(false);
		videoButton.setFocusPainted(false);
		videoButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// Music buttonEnteredMusic = new Music("staywithme.mp3", false);
				// buttonEnteredMusic.start();
				pictureButton.setVisible(false);
				drawingButton.setVisible(false);
				videoButton.setVisible(false);
				background = new ImageIcon(getClass().getClassLoader().getResource("seeYouSoon.PNG")).getImage();

				// MainPage mainPage = new MainPage();

			}
		});
		add(videoButton);

		pictureButton.setVisible(false);
		drawingButton.setVisible(false);
		videoButton.setVisible(false);
		
		
		
		
		fileInputButton.setBounds(476, 267, 365, 365);
		fileInputButton.setBorderPainted(false);
		fileInputButton.setContentAreaFilled(false);
		fileInputButton.setFocusPainted(false);
		fileInputButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				FileNameExtensionFilter filter = new FileNameExtensionFilter("jpg&png image files", "jpg", "png");
				JFileChooser chooser = new JFileChooser();
				chooser.setFileFilter(filter);
				
				int ret = chooser.showOpenDialog(null);
				if(ret!= JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(null, "���� ���� ����", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				String filePath=chooser.getSelectedFile().getPath();
				//System.out.println(filePath);
				BufferedImage image=null;
				try {
					image = ImageIO.read(new File(filePath));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(image.getHeight()<200 || image.getWidth()<200) {
					JOptionPane.showMessageDialog(null, "�׸� ũ�Ⱑ �ʹ� �۽��ϴ�\n �ּ� 200*200px �̻�", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				
				try {
					createMusic = new CreateMusic(image);
				} catch (InvalidMidiDataException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				fileImage = new ImageIcon(image).getImage();
				
				//�׸� �׸���
				//background = new ImageIcon(getClass().getClassLoader().getResource("service1Background2.PNG")).getImage();
				
				fileInputButton.setVisible(false);
				playButton.setVisible(true);
				background = new ImageIcon(getClass().getClassLoader().getResource("service1Background2.PNG")).getImage(); // TO
																										// DO
				pointer_service1Button.setVisible(true);

			}
		});
		add(fileInputButton);
		fileInputButton.setVisible(false);
	
		
		

		playButton.setBounds(454, 189, 366, 363);
		playButton.setBorderPainted(false);
		playButton.setContentAreaFilled(false);
		playButton.setFocusPainted(false);
		playButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				playButton.setVisible(false);
				stopButton.setVisible(true);
				createMusic.play();

			}
		});
		add(playButton);
		
		stopButton.setBounds(454, 189, 366, 363);
		stopButton.setBorderPainted(false);
		stopButton.setContentAreaFilled(false);
		stopButton.setFocusPainted(false);
		stopButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				playButton.setVisible(true);
				stopButton.setVisible(false);
				createMusic.stop();
				
			}
		});
		add(stopButton);
		stopButton.setVisible(false);
		playButton.setVisible(false);
//		
		
		
		
		
		saveButton.setBounds(23, 69, 394, 598);
		saveButton.setBorderPainted(false);
		saveButton.setContentAreaFilled(false);
		saveButton.setFocusPainted(false);
		saveButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				FileNameExtensionFilter filter = new FileNameExtensionFilter("wav&mp3 files", "wav", "mp3");
				JFileChooser chooser = new JFileChooser();
				chooser.setFileFilter(filter);
				
				int ret = chooser.showSaveDialog(null);
				if(ret!= JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(null, "���� ���� ����", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				String filePath=chooser.getSelectedFile().getPath();
				createMusic.record(filePath);
				//System.out.println(filePath);
			}
		});
		add(saveButton);
		saveButton.setVisible(false);
		
		
		againButton.setBounds(444, 69, 394, 598);
		againButton.setBorderPainted(false);
		againButton.setContentAreaFilled(false);
		againButton.setFocusPainted(false);
		againButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				saveButton.setVisible(false);
				againButton.setVisible(false);
				mainButton.setVisible(false);
				background = new ImageIcon(getClass().getClassLoader().getResource("service1Background1.PNG"))
						.getImage(); 
				fileInputButton.setVisible(true);
			}
		});
		add(againButton);
		againButton.setVisible(false);
		
		
		mainButton.setBounds(861, 69, 394, 598);
		mainButton.setBorderPainted(false);
		mainButton.setContentAreaFilled(false);
		mainButton.setFocusPainted(false);
		mainButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				saveButton.setVisible(false);
				againButton.setVisible(false);
				mainButton.setVisible(false);
				background = new ImageIcon(getClass().getClassLoader().getResource("mainBackground.PNG"))
						.getImage();
				pictureButton.setVisible(true);
				drawingButton.setVisible(true);
				videoButton.setVisible(true);
			}
		});
		add(mainButton);
		mainButton.setVisible(false);
		
		
		
		
		pointer_service1Button.setBounds(1145, 600, 84, 78);
		pointer_service1Button.setBorderPainted(false);
		pointer_service1Button.setContentAreaFilled(false);
		pointer_service1Button.setFocusPainted(false);
		pointer_service1Button.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				createMusic.stop();
				pointer_service1Button.setVisible(false);
				playButton.setVisible(false);
				stopButton.setVisible(false);
				background = new ImageIcon(getClass().getClassLoader().getResource("endBackground.PNG")).getImage();
				saveButton.setVisible(true);
				againButton.setVisible(true);
				mainButton.setVisible(true);
			}
		});
		add(pointer_service1Button);
		pointer_service1Button.setVisible(false);
		
		
		
		
		
		
		
		
	}

	public void paint(Graphics g) {
		screenImage = createImage(ArtPlatform.SCREEN_WIDTH, ArtPlatform.SCREEN_HEIGHT);
		screenGraphic = screenImage.getGraphics();
		screenDraw(screenGraphic);
		g.drawImage(screenImage, 0, 0, null);
	}

	public void screenDraw(Graphics g) {
		g.drawImage(background, 0, 0, null);
		paintComponents(g);
		this.repaint();
	}
}
